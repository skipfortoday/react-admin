module.exports = {
    'secret':'rahasiaku',
}