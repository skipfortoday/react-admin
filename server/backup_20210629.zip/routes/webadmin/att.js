const conn = require('/home/lviors/absensi/config/database.js')
const moment = require("moment");

exports.masukManual = (req, res) => {
    let parsing = {
        Tanggal: moment.parseZone(moment()).format('YYYY-MM-DD'),
        ScanMasuk: moment.parseZone(moment()).format('HH:mm:ss'),
        UserID: req.body.UserID,
        Nama: req.body.NamaUser
    }
    let ket = req.body.Keterangan == undefined ? '' : req.body.Keterangan;
    let caraMasuk = parseInt(req.body.IsFP) == 1 ? 'FP': 'MNL';
    let sql =
        `CALL ProsesMasukManual (
        '` + req.body.UserID +`',
        '` + parsing.Tanggal +`',
        '` + parsing.ScanMasuk + `',
        '` + req.body.Shift + `',
        '` + ket +`',  
        '` + req.headers.kodecabang +`',
        '` + caraMasuk+`' 
    )`;
    // console.log(sql);
    // res.send("ok")
    conn.query(sql, (err, results) => {
        if (err) throw err;
        res.send(results[0][0]);
    });
}

exports.pulangManual = (req, res) => {
    let parsing = {
        ScanPulang: moment.parseZone(moment()).format('HH:mm:ss'),
        UserID: req.body.UserID,
        Nama: req.body.NamaUser
    }
    let sql =
        `CALL ProsesPulang (
          '` + req.params.id + `',
          '` + parsing.ScanPulang + `',
          '` + req.body.KetPulang + `',
          '` + req.headers.kodecabang + `'
        )`;
        // res.send(sql);
    conn.query(sql, (err, results) => {
        if (err) throw err;
        res.send(JSON.stringify(parsing));
    });
}

exports.keluarManual = (req, res) => {
    let parsing = { KeluarKantor: moment.parseZone(moment()).format('HH:mm:ss'), UserID: req.body.UserID, Nama: req.body.NamaUser }
    let sql =
        `CALL ProsesKeluarKantor (
        '` + req.body.DatangID +`',
        '` + parsing.KeluarKantor +`',
        '` + req.body.KeteranganKeluar +`',
        '` + req.headers.kodecabang +`'
        )`;
    let query = conn.query(sql, (err, results) => {
        if (err) throw err;
        res.send(JSON.stringify(parsing));
    });
}

exports.kembaliManual = (req, res) => {
    let parsing = { KeluarKantor: moment.parseZone(moment()).format('HH:mm:ss'), UserID: req.body.UserID, Nama: req.body.NamaUser }
    let sql =
        `CALL ProsesKembaliKantor (
        '` + req.params.id + `',
        '` + parsing.KeluarKantor + `',
        '` + req.body.KeteranganKembali + `',
        '` + req.headers.kodecabang + `'
        )`;
    let query = conn.query(sql, (err, results) => {
        if (err) throw err;
        res.send(JSON.stringify(parsing));
    });
}

exports.istirahatManual = (req, res) => {
    let parsing = { KeluarKantor: moment.parseZone(moment()).format('HH:mm:ss'), UserID: req.body.UserID, Nama: req.body.NamaUser }
    let sql =
        `CALL ProsesIstirahatKeluar(
        '` + req.params.id + `',
        '` + parsing.KeluarKantor + `',
        '` + req.body.KetIstirahatKeluar + `'
        )`;
    let query = conn.query(sql, (err, results) => {
        if (err) throw err;
        res.send(JSON.stringify(parsing));
    });
}

exports.istirahatKembaliManual = (req, res) => {
    let parsing = { KeluarKantor: moment.parseZone(moment()).format('HH:mm:ss'), UserID: req.body.UserID, Nama: req.body.NamaUser }
    let sql =
        `CALL ProsesIstirahatKembali (
            '` + req.params.id + `',
            '` + parsing.KeluarKantor + `',
            '` + req.body.KetIstirahatKembali + `'
        )`;
    conn.query(sql, (err, results) => {
    if (err) throw err;
        res.send(JSON.stringify(parsing));
    });
}

exports.cekUserAfterFinger = (req, res) => {
    let id = req.params.id;
    let action = req.params.action;
    let q = `CALL CekUserAfterFinger('`+id+`','`+action+`', '`+req.headers.kodecabang+`')`;
    //console.log(q);
    conn.query(q, (err, result) => {
        if (err) throw err;
        res.send(result[0][0]);
    })
}

exports.optUserMasukManual = (req, res) => {
    conn.query(`CALL optUserMasukManual('`+req.headers.kodecabang+`')`, function (err, rows) {
        if (err) throw err;
        let user = rows[0];
        res.send(user);
    });
}

exports.optUserPulangManual = (req, res) => {
    conn.query(`CALL optUserPulangManual('`+req.headers.kodecabang+`')`, function (err, rows) {
        if (err) throw err;
        let user = rows[0];
        res.send(user);
    });
}

exports.optUserKeluarManual = (req, res) => {
    conn.query(`CALL optUserKeluarManual('`+req.headers.kodecabang+`')`, function (err, rows) {
        if (err) throw err;
        let user = rows[0];
        res.send(user);
    });
}

exports.optUserKembaliManual = (req, res) => {
    conn.query(`CALL optUserKembaliManual('`+req.headers.kodecabang+`')`, function (err, rows) {
        if (err) throw err;
        let user = rows[0];
        res.send(user);
    });
}

exports.optUserIstirahatKeluarManual = (req, res) => {
    conn.query(`CALL optUserIstirahatKeluarManual('`+req.headers.kodecabang+`')`, function (err, rows) {
        if (err) throw err;
        let user = rows[0];
        res.send(user);
    });
}

exports.optUserIstirahatKembaliManual = (req, res) => {
    conn.query(`CALL optUserIstirahatKembaliManual('`+req.headers.kodecabang+`')`, function (err, rows) {
        if (err) throw err;
        let user = rows[0];
        res.send(user);
    });
}